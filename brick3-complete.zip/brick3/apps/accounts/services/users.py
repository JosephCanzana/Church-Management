"""accounts.services.users: business rules for managing people (super-admin, admin, coordinator).

Same conventions as accounts.services: every function checks permission
first, does its work in `transaction.atomic()`, writes `log_action()` in the
same transaction, and reports a rule failure as ServiceError (a message that is
safe to show). Actions on a person who is already in the wanted state return
`changed=False` and log nothing, so a double click is harmless.

PASSWORDS: a new or reset password exists in plain text only inside the return
value (PasswordInfo) so the view can show it ONCE. It is never stored, logged
or put in the session, and audit_log would strip it anyway.

LOCK ORDER (so overlapping requests cannot deadlock): extensions first in
ascending id order, then people (the super-admin rows in ascending id order).
"""
import secrets
from collections import namedtuple
from dataclasses import dataclass, field

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import ProtectedError, RestrictedError
from django.utils import timezone

from apps.audit.services import log_action
from apps.core import services as core_services
from apps.core.services import ServiceError, consume_submission_token
from apps.core.text import clean_suffix, clean_text, title_case

from ..validators import generate_strong_password, validate_strong_password

from ..address import ADDRESS_FIELDS, check_address
from ..contact import PHONE_MESSAGE, clean_phone, is_valid_phone
from ..models import (
    AgeNetwork, ArchiveReason, DefaultPassword, Extension, Gender, PersonType, Role, Status, User,
    UserExtensionHistory,
)
from ..permissions import (
    ARCHIVE, CHANGE_PLACEMENT, DELETE, EDIT, GRANT_ACCOUNT, PROMOTE, RESET_PASSWORD, RESTORE, SUSPEND,
    UNSUSPEND,
    allowed_bulk_actions, assignable_roles, can_type_password, default_password_roles,
    default_password_view_roles, require_can_act,
    require_can_create, require_password_typer, require_placement_manager, require_user_manager,
)

ROLES_WITH_EXTENSION = (Role.COORDINATOR, Role.MEMBER)
# Who a person is: a change here re-runs the duplicate-name check.
IDENTITY_FIELDS = ("first_name", "middle_name", "last_name", "suffix", "birth_date")
# Optional contact details. Never written to audit_log (only the field NAMES that changed).
CONTACT_FIELDS = ("phone_number", *ADDRESS_FIELDS)
# Saved with the other details, but NOT part of who a person is (changing it never re-runs the
# duplicate-name check) and never written to audit_log: only the field name is logged.
PRIVATE_FIELDS = (*CONTACT_FIELDS, "gender")
USER_DETAIL_FIELDS = (*IDENTITY_FIELDS, *PRIVATE_FIELDS)
GENDER_REQUIRED_MESSAGE = "Choose a gender."
MAX_BULK = 100
MIN_PASSWORD_LENGTH = 8
# No 0/O, 1/l/I: generated passwords get read aloud and typed by hand.
PASSWORD_ALPHABET = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"


# ------------------------------------------------------------------ passwords
@dataclass
class PasswordInfo:
    """How a password was chosen, and what (if anything) may be shown once."""

    kind: str                 # "typed" | "default" | "generated" | "none" (cannot sign in)
    value: str = ""           # the plain text, only for "generated"

    @property
    def display(self):
        """What the show-once dialog prints in the password column."""
        if self.kind == "generated":
            return self.value
        if self.kind == "default":
            return "The default password"
        if self.kind == "none":
            return "No password (cannot sign in)"
        return "The password you typed"


def generate_password(length=12):
    """A random password a person can type without guessing which letter it is."""
    return "".join(secrets.choice(PASSWORD_ALPHABET) for _ in range(length))


def global_default_row(role):
    """The global default password for people of `role`, or None.

    The global default is the one a super-admin keeps. If several super-admins keep
    one, the most recently changed row of an active super-admin counts.
    """
    return (
        DefaultPassword.objects
        .filter(owner__role=Role.SUPER_ADMIN, owner__status=Status.ACTIVE, applies_to_role=role)
        .order_by("-updated_at", "-pk").first()
    )


def default_password_row(actor, role):
    """The DefaultPassword row `actor` uses when giving a person of `role` a default, or None.

    The password a person gets depends on WHO creates or resets them:
      super-admin  their own default for the role (the global one, by definition)
      admin        their own default for the role, else the global one
      coordinator  the global member password (a coordinator keeps none of their own)
    None means no default exists, and a password is generated instead.
    """
    if actor.role == Role.SUPER_ADMIN:
        if role not in default_password_roles(actor):
            return None
        return DefaultPassword.objects.filter(owner=actor, applies_to_role=role).first()
    if actor.role == Role.ADMIN:
        if role not in default_password_roles(actor):
            return None
        own = DefaultPassword.objects.filter(owner=actor, applies_to_role=role).first()
        return own or global_default_row(role)
    if actor.role == Role.COORDINATOR and role == Role.MEMBER:
        return global_default_row(role)
    return None


def reveal_default_password(actor, request, role=Role.MEMBER):
    """Show `actor` the default password they use for `role` (read-only) and log that they looked.

    This is what a coordinator's Default passwords button does: it displays the global member
    password and nothing else (a coordinator cannot set one). Returns the password, or None when
    none is set or it cannot be shown (saved before encryption existed, or the key changed).
    Only roles in `default_password_view_roles(actor)` may be looked at. The audit row says WHO
    looked and whether a password was shown, never the password itself.
    """
    require_user_manager(actor)
    if role not in default_password_view_roles(actor):
        raise PermissionDenied("You cannot see that password.")
    row = default_password_row(actor, role)
    plain = row.plain if row else None
    log_action(
        "default_password.view", actor=actor, request=request,
        entity_type="default_password", entity_id=row.pk if row else None,
        entity_label=f"{role} default password", after={"role": role, "shown": plain is not None},
    )
    return plain


def _default_password_hash(actor, role):
    """The hash of the default password `actor` uses for people of `role`, or None."""
    row = default_password_row(actor, role)
    return row.password_hash if row else None


def _set_initial_password(actor, person, typed):
    """Set `person`'s password: what was typed, else `actor`'s default, else a random one.

    Only the super-admin and admin may type one; a coordinator always gets the global member password.
    A guest or a no-account member never signs in, so they get an unusable password and nothing is shown.
    """
    if person.person_type != PersonType.MEMBER_ACCOUNT:
        person.set_unusable_password()
        return PasswordInfo("none")
    if typed:
        require_password_typer(actor)
        try:
            validate_strong_password(typed)
        except ValidationError as exc:
            raise ServiceError(exc.messages[0])
        person.set_password(typed)
        return PasswordInfo("typed")
    stored = _default_password_hash(actor, person.role)
    if stored:
        person.password = stored          # already a hash; copied, never decoded
        return PasswordInfo("default")
    value = generate_strong_password()
    person.set_password(value)
    return PasswordInfo("generated", value)


# ---------------------------------------------------------------------- names
NAME_FIELDS = ("first_name", "middle_name", "last_name")


def normalize_details(data):
    """Copy of `data` with the name parts the way the database stores them.

    Trimmed, single spaces, lowercase (`core.text.clean_text`), so "Joseph
    Canzana" and "joseph  canzana" are the same person. The screens show names
    through `name_case`.
    """
    cleaned = dict(data)
    for name in NAME_FIELDS:
        if name in cleaned:
            cleaned[name] = clean_text(cleaned[name])
    if "suffix" in cleaned:
        cleaned["suffix"] = clean_suffix(cleaned["suffix"])
    if "phone_number" in cleaned:
        cleaned["phone_number"] = clean_phone(cleaned["phone_number"])
    for name in ADDRESS_FIELDS:
        if name in cleaned:
            raw = cleaned[name] or ""
            # Like an extension: lowercase and single spaces, but a postal code keeps its case.
            cleaned[name] = " ".join(str(raw).split()) if name == "postal_code" else clean_text(raw)
    return cleaned


def check_contact(data, existing=None):
    """Raise ServiceError when the phone number or address in `data` breaks a rule.

    `data` is already normalized. Both are optional, so an empty phone and an empty
    address pass. A partly filled address needs a country, and a Philippine one must
    follow the same province > municipality > barangay and 4-digit postal rules as an
    extension (`accounts.address.check_address`). `existing` (the saved address of the
    person being edited) lets an old value that is not in the list stay until changed.
    """
    phone = data.get("phone_number") or ""
    if phone and not is_valid_phone(phone):
        raise ServiceError(PHONE_MESSAGE)
    values = {name: data.get(name) or "" for name in ADDRESS_FIELDS}
    if not any(values.values()):
        return
    if not values["country"]:
        raise ServiceError("Choose a country for the address, or clear the address.")
    problems = check_address(values, existing)
    if problems:
        raise ServiceError(next(iter(problems.values())))


def find_duplicate_people(
    first_name, middle_name, last_name, birth_date=None, *, suffix="", exclude_pk=None, limit=None,
):
    """People with the same name and suffix, oldest account first. Archived people count.

    The ONE duplicate-name rule: `find_duplicate_person` (user create and edit) and the
    attendance "same person?" prompt both use it. Two real people can share a name, so a
    match is ignored only when BOTH have a birth date and the dates differ. `__iexact` also
    catches rows saved before names were stored in lowercase. `middle_name=None` means "any
    middle name" (a first timer on an attendance sheet rarely gives one); "" means none.
    Callers pass names already cleaned with `normalize_details` / `clean_text`.
    """
    people = User.objects.select_related("extension").filter(
        first_name__iexact=first_name, last_name__iexact=last_name, suffix__iexact=suffix,
    )
    if middle_name is not None:
        people = people.filter(middle_name__iexact=middle_name)
    if exclude_pk is not None:
        people = people.exclude(pk=exclude_pk)
    found = []
    for other in people.order_by("pk"):
        if birth_date and other.birth_date and birth_date != other.birth_date:
            continue
        found.append(other)
        if limit is not None and len(found) >= limit:
            break
    return found


def find_duplicate_person(first_name, middle_name, last_name, birth_date=None, *, suffix="", exclude_pk=None):
    """Someone with the same name and suffix, or None. Archived people count.

    The first result of `find_duplicate_people`, which holds the rule.
    """
    found = find_duplicate_people(
        first_name, middle_name, last_name, birth_date, suffix=suffix, exclude_pk=exclude_pk, limit=1,
    )
    return found[0] if found else None


def duplicate_message(data, *, exclude_pk=None):
    """A sentence explaining the clash when `data` names someone who exists, else None."""
    data = normalize_details(data)
    other = find_duplicate_person(
        data.get("first_name") or "", data.get("middle_name") or "", data.get("last_name") or "",
        data.get("birth_date"), suffix=data.get("suffix") or "", exclude_pk=exclude_pk,
    )
    if other is None:
        return None
    where = " (archived)" if other.status == Status.ARCHIVED else ""
    return (
        f"{other.full_name}{where} already exists with Account ID {other.account_id}. "
        "If these are two different people, give both a birth date so they can be told apart."
    )


def _require_gender(value):
    """Raise ServiceError unless `value` is a real gender (a person cannot be saved without one)."""
    if value not in Gender.values:
        raise ServiceError(GENDER_REQUIRED_MESSAGE)


def _refuse_duplicate(data, *, exclude_pk=None):
    message = duplicate_message(data, exclude_pk=exclude_pk)
    if message:
        raise ServiceError(message)


# --------------------------------------------------------------------- locking
Locked = namedtuple("Locked", "person extension other_super_admins")


def _lock_extensions(ids):
    """Lock extension rows in ascending id order. Returns {id: Extension}."""
    ids = sorted({i for i in ids if i})
    if not ids:
        return {}
    rows = Extension.objects.select_for_update().filter(pk__in=ids).order_by("pk")
    return {e.pk: e for e in rows}


def _lock_person(pk):
    """Lock a person, their extension and (for a super-admin) every super-admin.

    Returns Locked(person, extension, other_super_admins) where the last is the
    OTHER super-admins who are active, used to protect the last one.
    """
    row = User.objects.filter(pk=pk).values("extension_id", "role").first()
    if row is None:
        raise ServiceError("That person no longer exists.")
    extension = _lock_extensions([row["extension_id"]]).get(row["extension_id"])
    if row["role"] == Role.SUPER_ADMIN:
        admins = list(User.objects.select_for_update().filter(role=Role.SUPER_ADMIN).order_by("pk"))
        person = next((a for a in admins if a.pk == pk), None)
        others = [a for a in admins if a.pk != pk and a.status == Status.ACTIVE]
    else:
        person = User.objects.select_for_update().filter(pk=pk).first()
        others = []
    if person is None or person.extension_id != row["extension_id"] or person.role != row["role"]:
        raise ServiceError("This person was just changed by someone else. Reload the page and try again.")
    return Locked(person, extension, others)


def _refuse_self(actor, person, what):
    if actor.pk == person.pk:
        raise ServiceError(f"You cannot {what} your own account.")


def _refuse_last_super_admin(locked, what):
    person = locked.person
    if person.role == Role.SUPER_ADMIN and person.status == Status.ACTIVE and not locked.other_super_admins:
        raise ServiceError(f"You cannot {what} the last active super-admin.")


def _log_person(action, actor, request, person, **kwargs):
    """One audit row about a person."""
    log_action(
        action,
        actor=actor,
        request=request,
        entity_type="app_user",
        entity_id=person.pk,
        entity_label=str(person),
        extension_id=person.extension_id,
        **kwargs,
    )


def _free_taken_seat(actor, request, ext, replace):
    """Make room in `ext` for a new coordinator by demoting the current one.

    Called with the extension row already locked. Without `replace` (the person
    did not confirm in the dialog) the seat stays taken and this refuses, so the
    server is the final guard and the dialog is only the polite part. The old
    coordinator stays in the extension as a member. Returns the old coordinator
    (or None). The caller puts the new coordinator in the seat and calls
    `_log_coordinator_change`.
    """
    if not replace:
        raise ServiceError(
            f"{title_case(ext.name)} already has a coordinator. Confirm the replacement to continue."
        )
    old = User.objects.select_for_update().filter(pk=ext.coordinator_id).first()
    if old is not None and old.role == Role.COORDINATOR:
        old.role = Role.MEMBER
        old.save(update_fields=["role", "updated_at"])
        _log_person("account.role_change", actor, request, old,
                    before={"role": Role.COORDINATOR}, after={"role": Role.MEMBER})
    ext.coordinator = None
    ext.save(update_fields=["coordinator", "updated_at"])
    return old


def _log_coordinator_change(actor, request, ext, old, new):
    """One audit row saying who the coordinator of `ext` was and is now."""
    log_action(
        "extension.coordinator_change", actor=actor, request=request,
        entity_type="extension", entity_id=ext.pk, entity_label=title_case(ext.name),
        extension_id=ext.pk,
        before={"coordinator": old.account_id if old else None},
        after={"coordinator": new.account_id},
    )


# ---------------------------------------------------------------------- create
@dataclass
class CreateResult:
    user: object = None
    password: PasswordInfo = None
    duplicate: bool = False


def create_user(actor, request, data, *, token):
    """Create a person. `data` comes from UserCreateForm.cleaned_data.

    token     -- the form's one-time token; a replay returns duplicate=True and
                 creates nothing.
    skip_password_change -- True leaves `must_change_password` off (the person keeps the password they
                 were given). Meant for test accounts; only the super-admin and admin may use it.
    person_type -- left out means `member_account`. A person who is not one (guest, no-account member)
                 must be a member and gets an unusable password.
    Coordinators: the new person is set as the coordinator of the extension in the
    same transaction. If the seat is taken, `data["replace_coordinator"]` (ticked by
    the confirmation dialog) demotes the old coordinator to a member of that
    extension; without it the request is refused.
    """
    require_user_manager(actor)
    data = normalize_details(data)
    role = data["role"]
    wanted = data.get("extension") if role in ROLES_WITH_EXTENSION else None
    # The role must be one the actor hands out and, for a coordinator, the extension their own.
    require_can_create(actor, role, wanted)
    if role in ROLES_WITH_EXTENSION and wanted is None:
        raise ServiceError("Choose an extension for this role.")
    check_contact(data)
    _require_gender(data.get("gender"))
    if data.get("age_network") and data["age_network"] not in AgeNetwork.values:
        raise ServiceError("Choose a valid age network.")

    with transaction.atomic():
        if not consume_submission_token(token):
            return CreateResult(duplicate=True)

        ext = _lock_extensions([wanted.pk]).get(wanted.pk) if wanted is not None else None
        replaced = None
        if wanted is not None:
            if ext is None or ext.is_archived:
                raise ServiceError("Choose an extension that is not archived.")
            if role == Role.COORDINATOR and ext.coordinator_id:
                replaced = _free_taken_seat(actor, request, ext, data.get("replace_coordinator"))

        _refuse_duplicate(data)

        # Skipping the password change would keep a shared default for good, so only those who may choose passwords can.
        skip_change = bool(data.get("skip_password_change")) and can_type_password(actor)
        person_type = data.get("person_type") or PersonType.MEMBER_ACCOUNT
        if person_type not in PersonType.values:
            raise ServiceError("Choose a valid person type.")
        if person_type != PersonType.MEMBER_ACCOUNT and role != Role.MEMBER:
            raise ServiceError("Only a member can be a guest or a member without an account.")
        person = User(
            first_name=data["first_name"],
            middle_name=data.get("middle_name", ""),
            last_name=data["last_name"],
            suffix=data.get("suffix", ""),
            birth_date=data.get("birth_date"),
            gender=data["gender"],
            age_network=data.get("age_network", ""),
            phone_number=data.get("phone_number", ""),
            **{name: data.get(name, "") for name in ADDRESS_FIELDS},
            role=role,
            extension=ext,
            person_type=person_type,
            status=Status.ACTIVE,
            must_change_password=person_type == PersonType.MEMBER_ACCOUNT and not skip_change,
            created_by=actor,
        )
        info = _set_initial_password(actor, person, data.get("password") or "")
        person.save()                      # User.save() generates the account id

        if ext is not None:
            UserExtensionHistory.objects.create(
                user=person, extension=ext, from_date=timezone.localdate(),
                reason=UserExtensionHistory.Reason.INITIAL,
            )
            if role == Role.COORDINATOR:
                ext.coordinator = person
                ext.save(update_fields=["coordinator", "updated_at"])
                if replaced is not None:
                    _log_coordinator_change(actor, request, ext, replaced, person)

        _log_person(
            "account.create", actor, request, person,
            after={
                "role": role,
                "extension_id": ext.pk if ext else None,
                "status": person.status,
                "person_type": person.person_type,
                "password_change_skipped": skip_change,
                "how_set": info.kind,          # not "password_...": audit drops those keys
            },
        )
    return CreateResult(user=person, password=info)


# ---------------------------------------------------------------------- update
def update_user(actor, request, ref, data):
    """Change a person's details, role and extension together. Returns (person, changed).

    Rules: no role change on yourself; the last active super-admin keeps their
    role; a coordinator seat is cleared when someone leaves it and taken when
    someone enters it (an extension has one coordinator); moving extension
    closes the open history row and opens a new one. Taking a seat that is
    already filled needs `data["replace_coordinator"]` (the confirmation
    dialog); the old coordinator then becomes a member of that extension.
    """
    require_user_manager(actor)
    data = normalize_details(data)
    new_role = data["role"]
    wanted = data.get("extension") if new_role in ROLES_WITH_EXTENSION else None
    if new_role in ROLES_WITH_EXTENSION and wanted is None:
        raise ServiceError("Choose an extension for this role.")

    with transaction.atomic():
        current_ext_id = User.objects.filter(pk=ref.pk).values_list("extension_id", flat=True).first()
        exts = _lock_extensions([current_ext_id, wanted.pk if wanted else None])
        # Lock order: people in ascending id order. The coordinator who may be
        # replaced is locked together with this person before _lock_person.
        seat = exts[wanted.pk].coordinator_id if wanted is not None and wanted.pk in exts else None
        list(User.objects.select_for_update()
             .filter(pk__in=[p for p in (ref.pk, seat) if p]).order_by("pk")
             .values_list("pk", flat=True))
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, EDIT)
        if person.status == Status.ARCHIVED:
            raise ServiceError("Restore this person before editing them.")
        # Phone and address are checked on what the person would end up with.
        check_contact(
            {name: data[name] if name in data else getattr(person, name) for name in CONTACT_FIELDS},
            existing={name: getattr(person, name) for name in ADDRESS_FIELDS},
        )
        # Checked on the locked row: keeping the current role is always fine (a
        # super-admin stays one); giving a role nobody can hand out is not.
        if new_role != person.role and new_role not in assignable_roles(actor):
            raise PermissionDenied("You cannot give that role.")
        old_ext = exts.get(person.extension_id)
        if person.extension_id and old_ext is None:
            raise ServiceError("This person was just changed by someone else. Reload the page and try again.")
        new_ext = exts.get(wanted.pk) if wanted is not None else None

        before = {name: getattr(person, name) for name in USER_DETAIL_FIELDS}
        for name in USER_DETAIL_FIELDS:
            if name in data:
                setattr(person, name, data[name])
        # Gender is required, but only checked here, on an edit: people saved before the rule stay
        # blank until someone edits them, and then they must be given one.
        _require_gender(person.gender)
        details_changed = [n for n in USER_DETAIL_FIELDS if before[n] != getattr(person, n)]
        if any(n in IDENTITY_FIELDS for n in details_changed):
            # Only a change to who they are can clash; fixing a phone number must never be blocked by one.
            _refuse_duplicate({n: getattr(person, n) for n in IDENTITY_FIELDS}, exclude_pk=person.pk)
        old_role = person.role
        old_ext_id = person.extension_id
        role_changed = new_role != old_role
        ext_changed = (new_ext.pk if new_ext else None) != old_ext_id

        if role_changed:
            _refuse_self(actor, person, "change the role of")
            if new_role != Role.SUPER_ADMIN:
                _refuse_last_super_admin(locked, "change the role of")
        if (role_changed or ext_changed) and actor.pk != person.pk:
            # A coordinator can edit details but never move or re-role anyone.
            require_can_act(actor, person, CHANGE_PLACEMENT)
        if ext_changed and new_ext is not None and new_ext.is_archived:
            raise ServiceError("Choose an extension that is not archived.")
        if not (details_changed or role_changed or ext_changed):
            return person, False

        # The seat is wanted but taken: demote its coordinator (only when confirmed).
        replaced = None
        if new_role == Role.COORDINATOR and new_ext.coordinator_id not in (None, person.pk):
            replaced = _free_taken_seat(actor, request, new_ext, data.get("replace_coordinator"))

        # Leaving the coordinator seat (a different role, or a different extension).
        if (
            old_role == Role.COORDINATOR and old_ext is not None
            and old_ext.coordinator_id == person.pk
            and (new_role != Role.COORDINATOR or new_ext is None or new_ext.pk != old_ext.pk)
        ):
            old_ext.coordinator = None
            old_ext.save(update_fields=["coordinator", "updated_at"])

        person.role = new_role
        person.extension = new_ext
        person.save(update_fields=[*details_changed, "role", "extension", "updated_at"])

        # Taking the coordinator seat.
        if new_role == Role.COORDINATOR and new_ext.coordinator_id != person.pk:
            new_ext.coordinator = person
            new_ext.save(update_fields=["coordinator", "updated_at"])
            if replaced is not None:
                _log_coordinator_change(actor, request, new_ext, replaced, person)

        if ext_changed:
            UserExtensionHistory.objects.filter(user=person, to_date__isnull=True).update(
                to_date=timezone.localdate()
            )
            if new_ext is not None:
                UserExtensionHistory.objects.create(
                    user=person, extension=new_ext, from_date=timezone.localdate(),
                    reason=UserExtensionHistory.Reason.MANUAL,
                )

        if details_changed:
            shown = [n for n in details_changed if n not in PRIVATE_FIELDS]
            after = {n: getattr(person, n) for n in shown}
            contact = [n for n in details_changed if n in PRIVATE_FIELDS]
            if contact:
                after["contact_fields_changed"] = contact     # names only, never the phone, address or gender
            _log_person(
                "account.update", actor, request, person,
                before={n: before[n] for n in shown}, after=after,
            )
        if role_changed:
            _log_person("account.role_change", actor, request, person,
                        before={"role": old_role}, after={"role": new_role})
        if ext_changed:
            _log_person("account.extension_change", actor, request, person,
                        before={"extension_id": old_ext_id},
                        after={"extension_id": new_ext.pk if new_ext else None})
    return person, True


# --------------------------------------------------------------- status changes
def archive_user(actor, request, ref):
    """Archive a person (not yourself, not the last active super-admin).

    A coordinator leaves the seat and becomes a member, so restoring them later
    never brings back a coordinator the extension no longer has.
    """
    require_user_manager(actor)
    with transaction.atomic():
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, ARCHIVE)
        if person.status == Status.ARCHIVED:
            return person, False
        _refuse_self(actor, person, "archive")
        _refuse_last_super_admin(locked, "archive")

        old_status = person.status
        cleared = _clear_special_roles(person)      # an archived person no longer holds a seat
        extra = ["status", "archive_reason"]
        if person.role == Role.COORDINATOR:
            ext = locked.extension
            if ext is not None and ext.coordinator_id == person.pk:
                ext.coordinator = None
                ext.save(update_fields=["coordinator", "updated_at"])
            person.role = Role.MEMBER
            extra.append("role")
            _log_person("account.role_change", actor, request, person,
                        before={"role": Role.COORDINATOR}, after={"role": Role.MEMBER})
        person.status = Status.ARCHIVED
        person.archive_reason = ArchiveReason.MANUAL
        core_services.archive(person, extra_fields=extra)
        _log_person("account.archive", actor, request, person,
                    before={"status": old_status},
                    after={"status": Status.ARCHIVED, "special_roles_cleared": cleared})
    return person, True


def restore_user(actor, request, ref):
    """Bring an archived person back (their extension must not be archived)."""
    require_user_manager(actor)
    with transaction.atomic():
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, RESTORE)
        if person.status != Status.ARCHIVED:
            return person, False
        ext = locked.extension
        if ext is not None and ext.is_archived:
            raise ServiceError(f"{ext.name} is archived. Restore the extension first.")
        person.status = Status.ACTIVE
        person.archive_reason = None
        core_services.restore(person, extra_fields=["status", "archive_reason"])
        _log_person("account.restore", actor, request, person,
                    before={"status": Status.ARCHIVED}, after={"status": person.status})
    return person, True


def suspend_user(actor, request, ref):
    """Block login without losing anything. Reversible; never purged."""
    require_user_manager(actor)
    with transaction.atomic():
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, SUSPEND)
        if person.status == Status.SUSPENDED:
            return person, False
        if person.status == Status.ARCHIVED:
            raise ServiceError("Restore this person before suspending them.")
        _refuse_self(actor, person, "suspend")
        _refuse_last_super_admin(locked, "suspend")
        old_status = person.status
        person.status = Status.SUSPENDED
        person.save(update_fields=["status", "updated_at"])
        _log_person("account.suspend", actor, request, person,
                    before={"status": old_status}, after={"status": Status.SUSPENDED})
    return person, True


def unsuspend_user(actor, request, ref):
    """Lift a suspension."""
    require_user_manager(actor)
    with transaction.atomic():
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, UNSUSPEND)
        if person.status != Status.SUSPENDED:
            return person, False
        person.status = Status.ACTIVE
        person.save(update_fields=["status", "updated_at"])
        _log_person("account.unsuspend", actor, request, person,
                    before={"status": Status.SUSPENDED}, after={"status": person.status})
    return person, True


# ------------------------------------------------------- promote / grant account
def promote_guest(actor, request, ref):
    """Turn a guest into a member without an account. Returns (person, changed).

    Changes the EXISTING row (never a second one for the same person), so the Account ID, the
    attendance history and the extension stay. Only an active guest can be promoted: a suspended
    one is blocked until a leader lifts that, and an archived one must be restored first. Someone who
    is already a member (with or without an account) is left alone (`changed=False`).
    """
    require_user_manager(actor)
    with transaction.atomic():
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, PROMOTE)
        if person.person_type != PersonType.GUEST:
            return person, False
        if person.status == Status.ARCHIVED:
            raise ServiceError("Restore this person before promoting them.")
        if person.status == Status.SUSPENDED:
            raise ServiceError("Unsuspend this person before promoting them.")
        person.person_type = PersonType.MEMBER_RECORD
        person.save(update_fields=["person_type", "updated_at"])
        _log_person("account.promote", actor, request, person,
                    before={"person_type": PersonType.GUEST},
                    after={"person_type": PersonType.MEMBER_RECORD})
    return person, True


@dataclass
class GrantResult:
    user: object = None
    password: PasswordInfo = None
    duplicate: bool = False


def grant_account(actor, request, ref, *, token, typed=""):
    """Give a member without an account a sign-in. Returns a GrantResult (password shown once).

    Same password rules as a new account (`_set_initial_password`: typed by an admin, else the actor's
    default, else generated) and the person must change it at first sign-in. Changes the EXISTING
    row from `member_record` to `member_account`. A guest is promoted first; someone who already has
    an account is refused with a plain message, since a second click should not look like a success.
    A replayed token returns duplicate=True and changes nothing.
    """
    require_user_manager(actor)
    with transaction.atomic():
        if not consume_submission_token(token):
            return GrantResult(duplicate=True)
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, GRANT_ACCOUNT)
        if person.status == Status.ARCHIVED:
            raise ServiceError("Restore this person before giving them an account.")
        if person.status == Status.SUSPENDED:
            raise ServiceError("Unsuspend this person before giving them an account.")
        if person.person_type == PersonType.MEMBER_ACCOUNT:
            raise ServiceError("This person already has an account.")
        if person.person_type == PersonType.GUEST:
            raise ServiceError("Promote this guest to a member first.")
        ext = locked.extension
        if ext is None or ext.is_archived:
            raise ServiceError("Put this person in an extension that is not archived first.")
        person.person_type = PersonType.MEMBER_ACCOUNT        # before the password: guests get none
        info = _set_initial_password(actor, person, typed)
        person.must_change_password = True
        person.save(update_fields=["person_type", "password", "must_change_password", "updated_at"])
        _log_person("account.grant_account", actor, request, person,
                    before={"person_type": PersonType.MEMBER_RECORD},
                    after={"person_type": PersonType.MEMBER_ACCOUNT, "needs_change": True,
                           "how_set": info.kind})
    return GrantResult(user=person, password=info)


# ---------------------------------------------------------------- reset password
@dataclass
class ResetResult:
    user: object = None
    password: PasswordInfo = None
    duplicate: bool = False


def _reset_password(actor, request, ref, typed=""):
    """Give a person a new password: `typed`, else the actor's default, else generated.

    Returns (person, info).
    """
    with transaction.atomic():
        locked = _lock_person(ref.pk)
        person = locked.person
        require_can_act(actor, person, RESET_PASSWORD)
        if person.status == Status.ARCHIVED:
            raise ServiceError("Restore this person before resetting their password.")
        _refuse_self(actor, person, "reset the password of")
        if person.person_type != PersonType.MEMBER_ACCOUNT:
            raise ServiceError("This person has no account, so there is no password to reset.")
        info = _set_initial_password(actor, person, typed)
        # A reset only sets the flag: the status (active or suspended) is left as it is.
        person.must_change_password = True
        # Changing the hash also signs the person out of every open session.
        person.save(update_fields=["password", "must_change_password", "updated_at"])
        _log_person("account.password_reset", actor, request, person,
                    after={"needs_change": True, "how_set": info.kind})
    return person, info


def reset_password(actor, request, ref, *, token, typed=""):
    """Reset one person's password. A replayed token returns duplicate=True.

    `typed` is an optional custom password (must pass the strong-password rule); empty means the
    actor's default for the person's role, else a generated one.
    """
    require_user_manager(actor)
    with transaction.atomic():
        if not consume_submission_token(token):
            return ResetResult(duplicate=True)
        person, info = _reset_password(actor, request, ref, typed)
    return ResetResult(user=person, password=info)


# ------------------------------------------------------------------ force delete
def force_delete_user(actor, request, ref):
    """Permanently delete an ARCHIVED person (not yourself). Returns (None, True).

    The audit row is written first in the same transaction; if the database
    refuses the delete (other records still point at the person) everything,
    including that row, rolls back. The profile image is removed from disk only
    after the delete has committed.
    """
    require_user_manager(actor)
    try:
        with transaction.atomic():
            locked = _lock_person(ref.pk)
            person = locked.person
            require_can_act(actor, person, DELETE)
            if person.status != Status.ARCHIVED:
                raise ServiceError("Only archived people can be deleted.")
            _refuse_self(actor, person, "delete")
            image = person.profile_image
            image_name, storage = (image.name, image.storage) if image else (None, None)
            _log_person("account.delete", actor, request, person,
                        before={"role": person.role, "extension_id": person.extension_id})
            core_services.force_delete(person)
            if image_name:
                transaction.on_commit(lambda: storage.delete(image_name))
    except (ProtectedError, RestrictedError):
        raise ServiceError(
            "This person is still referenced by other records, so they cannot be deleted yet."
        )
    return None, True


# ------------------------------------------------- people inside one extension
def _clear_special_roles(person):
    """Delete the person's special roles (attendance, tithes); returns how many.

    Special roles have a limit per extension, so they never travel with someone
    to another extension.
    """
    from ..models import UserSpecialRole   # imported here: only moves need it

    removed, _ = UserSpecialRole.objects.filter(user=person).delete()
    return removed


def auto_transfer_visitor(actor, request, person_id, target_extension_id, on_date):
    """Move an active member after attendance has confirmed repeated visits to a new extension.

    The attendance service decides whether the visit threshold has been reached. This accounts-owned
    operation rechecks the member and extension under locks, moves the open history row, clears
    extension-specific roles, and records the automatic transfer without importing attendance.
    """
    if not getattr(actor, "is_authenticated", False) or not actor.is_active:
        raise PermissionDenied("A signed-in leader must upload attendance before an automatic transfer.")
    if actor.role not in (Role.SUPER_ADMIN, Role.ADMIN) and not (
            actor.role == Role.COORDINATOR and actor.extension_id == target_extension_id):
        raise PermissionDenied("You cannot record an automatic transfer for this extension.")

    with transaction.atomic():
        current_extension_id = User.objects.filter(pk=person_id).values_list("extension_id", flat=True).first()
        if current_extension_id is None:
            return False
        extensions = _lock_extensions([current_extension_id, target_extension_id])
        target = extensions.get(target_extension_id)
        person = User.objects.select_for_update().filter(pk=person_id).first()
        if person is None or person.extension_id != current_extension_id:
            return False
        if target is None or target.is_archived or person.extension_id == target.pk:
            return False
        if person.role != Role.MEMBER or person.status != Status.ACTIVE:
            return False

        old_extension_id = person.extension_id
        cleared = _clear_special_roles(person)
        person.extension = target
        person.save(update_fields=["extension", "updated_at"])
        UserExtensionHistory.objects.filter(user=person, to_date__isnull=True).update(to_date=on_date)
        UserExtensionHistory.objects.create(
            user=person, extension=target, from_date=on_date,
            reason=UserExtensionHistory.Reason.AUTO_TRANSFER,
        )
        _log_person(
            "account.extension_auto_transfer", actor, request, person,
            before={"extension_id": old_extension_id},
            after={"extension_id": target.pk, "special_roles_cleared": cleared},
        )
    return True


def move_person(actor, request, person_ref, target_ref, *, confirmed=False, expected_from=None):
    """Put a person in `target` (transfer in from another extension, or add someone who has none). Returns (person, changed).

    Rules:
      - Only members and coordinators belong to an extension (admins and
        super-admins never do), the person must not be archived, the target
        must not be archived.
      - Someone who already belongs to ANOTHER extension is moved only when
        `confirmed` is true (the dialog "this person is from another extension").
      - A moving coordinator frees the seat of the old extension and arrives as
        a member; their special roles are cleared.
      - `expected_from` (an extension id) makes the call fail calmly when the
        person is no longer in the extension the page showed.
    Lock order: extensions ascending, then the person.
    """
    require_user_manager(actor)
    require_placement_manager(actor)
    with transaction.atomic():
        current = User.objects.filter(pk=person_ref.pk).values_list("extension_id", flat=True).first()
        exts = _lock_extensions([current, target_ref.pk])
        person = _lock_person(person_ref.pk).person
        require_can_act(actor, person, CHANGE_PLACEMENT)
        target = exts.get(target_ref.pk)
        if target is None:
            raise ServiceError("That extension no longer exists.")
        if target.is_archived:
            raise ServiceError("Choose an extension that is not archived.")
        if person.status == Status.ARCHIVED:
            raise ServiceError(f"{person.full_name} is archived. Restore them first.")
        if person.role not in ROLES_WITH_EXTENSION:
            raise ServiceError(f"{person.full_name} is an {Role(person.role).label.lower()} and does not belong to an extension.")
        if expected_from is not None and person.extension_id != expected_from:
            raise ServiceError(f"{person.full_name} is no longer in this extension.")
        if person.extension_id == target.pk:
            return person, False
        old = exts.get(person.extension_id)
        if old is not None and not confirmed:
            raise ServiceError(
                f"{person.full_name} belongs to {title_case(old.name)}. Confirm the move to continue."
            )

        old_role, old_ext_id = person.role, person.extension_id
        if old is not None and old.coordinator_id == person.pk:
            old.coordinator = None
            old.save(update_fields=["coordinator", "updated_at"])
        person.role = Role.MEMBER
        person.extension = target
        cleared = _clear_special_roles(person)
        person.save(update_fields=["role", "extension", "updated_at"])

        UserExtensionHistory.objects.filter(user=person, to_date__isnull=True).update(
            to_date=timezone.localdate()
        )
        UserExtensionHistory.objects.create(
            user=person, extension=target, from_date=timezone.localdate(),
            reason=UserExtensionHistory.Reason.MANUAL,
        )
        if old_role != Role.MEMBER:
            _log_person("account.role_change", actor, request, person,
                        before={"role": old_role}, after={"role": Role.MEMBER})
        _log_person("account.extension_change", actor, request, person,
                    before={"extension_id": old_ext_id},
                    after={"extension_id": target.pk, "special_roles_cleared": cleared})
    return person, True


def transfer_people_in(actor, request, extension, ids, *, token, confirmed=False):
    """Transfer people INTO one extension (max 100). Returns BulkResult.

    Same contract as `run_bulk`: one transaction per person in ascending id order,
    anyone it does not apply to is skipped with a reason, and the one-time token
    is consumed first so a repeated submission does nothing. People who belong to
    another extension are only moved when `confirmed` is true (the confirmation
    dialog); the others (no extension) are simply added.
    """
    require_user_manager(actor)
    require_placement_manager(actor)
    ids = sorted({int(i) for i in ids})
    if not ids:
        raise ServiceError("Select at least one person.")
    if len(ids) > MAX_BULK:
        raise ServiceError(f"Select at most {MAX_BULK} people at a time.")

    with transaction.atomic():
        if not consume_submission_token(token):
            return BulkResult(duplicate=True)

    result = BulkResult()
    for pk in ids:
        person = User.objects.filter(pk=pk).first()
        if person is None:
            result.skipped.append((f"#{pk}", "no longer exists"))
            continue
        try:
            _, changed = move_person(actor, request, person, extension, confirmed=confirmed)
        except ServiceError as exc:
            result.skipped.append((person.full_name, str(exc)))
            continue
        if changed:
            result.done.append(person.full_name)
        else:
            result.skipped.append((person.full_name, "already there"))
    return result


# --------------------------------------------------------------------------- bulk
BULK_ACTIONS = {
    "archive": archive_user,
    "restore": restore_user,
    "suspend": suspend_user,
    "unsuspend": unsuspend_user,
    "delete": force_delete_user,
    "promote": promote_guest,
}
BULK_ACTION_NAMES = (*BULK_ACTIONS, "reset_password")
# Shown when an action had nothing to do for a person.
NOTHING_TO_DO = {
    "archive": "already archived",
    "restore": "not archived",
    "suspend": "already suspended",
    "unsuspend": "not suspended",
    "promote": "not a guest",
}


@dataclass
class BulkResult:
    done: list = field(default_factory=list)       # labels of people it worked for
    skipped: list = field(default_factory=list)    # (label, reason)
    passwords: list = field(default_factory=list)  # [name, account id, text] for reset_password
    duplicate: bool = False


def run_bulk(actor, request, action, ids, *, token):
    """Run one action over many people. Each person is its own transaction.

    A person the action cannot apply to (yourself, the last super-admin, wrong
    status, gone) is skipped with a reason; it never fails the others. People
    are handled in ascending id order. The token is consumed first, so a
    repeated submission of the same selection does nothing.
    """
    require_user_manager(actor)
    if action not in BULK_ACTION_NAMES or action not in allowed_bulk_actions(actor):
        raise ServiceError("That action is not available.")
    ids = sorted({int(i) for i in ids})
    if not ids:
        raise ServiceError("Select at least one person.")
    if len(ids) > MAX_BULK:
        raise ServiceError(f"Select at most {MAX_BULK} people at a time.")

    with transaction.atomic():
        if not consume_submission_token(token):
            return BulkResult(duplicate=True)

    result = BulkResult()
    for pk in ids:
        # for_user: someone outside the actor's reach looks exactly like someone who is gone,
        # so a name from another extension is never shown in the result.
        person = User.objects.for_user(actor).filter(pk=pk).first()
        if person is None:
            result.skipped.append((f"#{pk}", "no longer exists"))
            continue
        label = person.full_name
        try:
            if action == "reset_password":
                _, info = _reset_password(actor, request, person)
                result.passwords.append([person.full_name, person.account_id, info.display])
                result.done.append(label)
            else:
                _, changed = BULK_ACTIONS[action](actor, request, person)
                if changed:
                    result.done.append(label)
                else:
                    result.skipped.append((label, NOTHING_TO_DO.get(action, "nothing to do")))
        except PermissionDenied:
            result.skipped.append((label, "you cannot do this to them"))
        except ServiceError as exc:
            result.skipped.append((label, str(exc)))

    if action == "archive" and len(result.done) >= 2:
        log_action(
            "account.bulk_archive", actor=actor, request=request, entity_type="app_user",
            after={"count": len(result.done)},
        )
    return result