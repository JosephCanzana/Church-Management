"""accounts.forms: input validation for the accounts app.

Forms only check the SHAPE of the input (is it empty, does it look like an
account id or an email, is the name taken). Whether a password is actually
correct is decided by the backend in `accounts/backends.py`, and every
business rule lives in `accounts/services.py`.
"""
import re
from datetime import date
from functools import cached_property

from django import forms
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.utils import timezone

from django.db.models import Q

from apps.core.text import clean_suffix as normalize_suffix, clean_text, title_case

from .address import ADDRESS_FIELDS, COUNTRIES, HIERARCHY, PHILIPPINES, canonical_country, check_address
from .contact import PHONE_MESSAGE, clean_phone, is_valid_phone
from .models import Extension, Gender, Role, Status, User
from .permissions import assignable_roles, can_type_password
from .validators import validate_strong_password, STRONG_PASSWORD_MESSAGE

# One message for every login failure, so the page never reveals whether the
# account exists, the password was wrong, or the account is archived.
GENERIC_LOGIN_ERROR = "The account ID or password is incorrect."

# Same rule as the `app_user_account_id_format` database constraint.
ACCOUNT_ID_PATTERN = re.compile(r"^[1-9][0-9]{7,}$")


# ============================================================ login
class LoginForm(forms.Form):
    """Account id (or verified email) plus password."""

    identifier = forms.CharField(max_length=254, strip=True)
    # strip=False: spaces at the start or end may be part of a password.
    password = forms.CharField(strip=False, widget=forms.PasswordInput)

    def clean_identifier(self):
        """Accept only something shaped like an account id or an email.

        A badly shaped value gets the SAME generic message as a wrong
        password, so the form never gives extra hints about what is valid.
        """
        value = self.cleaned_data["identifier"]
        if "@" in value:
            try:
                validate_email(value)
            except ValidationError:
                raise ValidationError(GENERIC_LOGIN_ERROR)
        elif not ACCOUNT_ID_PATTERN.match(value):
            raise ValidationError(GENERIC_LOGIN_ERROR)
        return value


# ============================================================ extensions
class ExtensionForm(forms.ModelForm):
    """Create or edit an extension. The view passes `cleaned_data` to the service.

    - Fields run from the widest area to the smallest: country, province,
      municipality, barangay, postal code, street, building number.
    - Every field is required except street and building number.
    - Input is cleaned to lowercase with single spaces (`core.text.clean_text`);
      the form shows saved values back in title case.
    - For the Philippines the province, municipality and barangay must come
      from `accounts.address` (the template turns them into cascading
      dropdowns, this class is the server-side check).
    - Invalid fields get `aria-invalid` from Django, which input.css styles.
    """

    #: Order of the fields (the template draws them by hand in this order).
    field_order = [
        "name", "country", "province", "municipality", "barangay",
        "postal_code", "street", "building_number", "is_main_church",
    ]
    #: The fields that may stay empty (a tick box is never "required").
    OPTIONAL_FIELDS = {"street", "building_number", "is_main_church"}
    #: Fields shown back in title case when an extension is edited.
    TITLE_FIELDS = ("name", "province", "municipality", "barangay", "street", "building_number")

    # Declared here (not just in Meta) because it is a dropdown, not free text.
    # The initial value is the model default for a new extension.
    country = forms.ChoiceField(label="Country", initial=PHILIPPINES, choices=[])

    class Meta:
        model = Extension
        fields = [
            "name", "country", "province", "municipality", "barangay",
            "postal_code", "street", "building_number", "is_main_church",
        ]
        widgets = {
            "is_main_church": forms.CheckboxInput(attrs={"class": "mt-0.5 size-4 accent-accent"}),
            "name": forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
            "province": forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
            "municipality": forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
            "barangay": forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
            "postal_code": forms.TextInput(attrs={
                "class": "input font-mono", "maxlength": "10", "inputmode": "numeric",
                "autocomplete": "off",
            }),
            "street": forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
            "building_number": forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
        }
        labels = {"name": "Extension name", "is_main_church": "Main church"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.required = name not in self.OPTIONAL_FIELDS

        choices = [("", "Choose a country")] + [(c, c) for c in COUNTRIES]
        saved_country = self.instance.country if self.instance.pk else ""
        if saved_country and not canonical_country(saved_country):
            # An old value that is not in the list stays selectable until changed.
            old = title_case(saved_country)
            choices.append((old, old))
        self.fields["country"].choices = choices

        if self.instance.pk and not self.is_bound:
            # Saved values are lowercase (or old mixed case); show them as titles.
            for name in self.TITLE_FIELDS:
                self.initial[name] = title_case(getattr(self.instance, name))
            self.initial["country"] = canonical_country(saved_country) or title_case(saved_country)

    @property
    def address_state(self):
        """Current country/province/municipality/barangay for the page's JavaScript."""
        return {name: self[name].value() or "" for name in HIERARCHY}

    @property
    def current_main_church(self):
        """Title-case name of ANOTHER extension that holds the main church tag, or "".

        The page uses it to say that ticking the box moves the tag from that extension.
        """
        others = Extension.objects.filter(is_main_church=True)
        if self.instance.pk:
            others = others.exclude(pk=self.instance.pk)
        other = others.first()
        return title_case(other.name) if other else ""

    def _get_validation_exclusions(self):
        """Keep the main church tag out of the model's constraint check.

        Ticking it is allowed even when another extension holds the tag: the service moves the tag
        in one transaction, so the unique constraint must not refuse the form first.
        """
        exclude = super()._get_validation_exclusions()
        exclude.add("is_main_church")
        return exclude

    # --- cleaning: everything stored lowercase ---------------------------
    def _lowered(self, name):
        return clean_text(self.cleaned_data.get(name))

    def clean_country(self):
        return self._lowered("country")

    def clean_province(self):
        return self._lowered("province")

    def clean_municipality(self):
        return self._lowered("municipality")

    def clean_barangay(self):
        return self._lowered("barangay")

    def clean_street(self):
        return self._lowered("street")

    def clean_building_number(self):
        return self._lowered("building_number")

    def clean_postal_code(self):
        """Single spaces only; the case is left alone (foreign codes like 'SW1A 1AA')."""
        return " ".join((self.cleaned_data.get("postal_code") or "").split())

    def clean_name(self):
        """Lowercase, single spaces, and not used by another extension.

        The database unique index is case-sensitive, so "Cabanatuan" and
        "cabanatuan" would both pass it; this check closes that gap.
        """
        name = self._lowered("name")
        taken = Extension.objects.filter(name__iexact=name)
        if self.instance.pk:
            taken = taken.exclude(pk=self.instance.pk)
        if taken.exists():
            raise ValidationError("An extension with this name already exists.")
        return name

    def clean(self):
        """Apply the Philippine address rules (same function the service uses)."""
        cleaned = super().clean()
        existing = None
        if self.instance.pk:
            # clean() runs before the instance is updated, so these are the saved values.
            existing = {name: getattr(self.instance, name) for name in self.fields}
        for field, message in check_address(cleaned, existing).items():
            if field in self.fields and field not in self.errors:
                self.add_error(field, message)
        return cleaned


class ExtensionFilterForm(forms.Form):
    """Search, status filter and sort for the extension list (GET parameters)."""

    STATUS_CHOICES = [("active", "Active"), ("archived", "Archived"), ("all", "All")]
    SORT_CHOICES = [
        ("name", "Name, A to Z"),
        ("-name", "Name, Z to A"),
        ("-created_at", "Newest first"),
        ("created_at", "Oldest first"),
    ]

    q = forms.CharField(
        required=False, strip=True, max_length=100, label="Search",
        widget=forms.TextInput(attrs={"class": "input", "placeholder": "Name, barangay or municipality"}),
    )
    status = forms.ChoiceField(
        required=False, choices=STATUS_CHOICES,
        widget=forms.Select(attrs={"class": "input"}),
    )
    sort = forms.ChoiceField(
        required=False, choices=SORT_CHOICES, label="Sort by",
        widget=forms.Select(attrs={"class": "input"}),
    )


class CoordinatorChoiceField(forms.ModelChoiceField):
    """Shows people as 'Full name (account id)'."""

    def label_from_instance(self, obj):
        return f"{obj.full_name} ({obj.account_id})"


class ExtensionChoiceField(forms.ModelChoiceField):
    """Shows extension names in title case in the person form's dropdown."""

    def label_from_instance(self, obj):
        return title_case(obj.name)


class AssignCoordinatorForm(forms.Form):
    """Pick the coordinator from the members of one extension."""

    user = CoordinatorChoiceField(
        queryset=User.objects.none(),
        empty_label="Choose a member",
        label="New coordinator",
        widget=forms.Select(attrs={"class": "input"}),
    )

    def __init__(self, *args, extension, **kwargs):
        super().__init__(*args, **kwargs)
        people = (
            User.objects.filter(extension=extension, role__in=[Role.MEMBER, Role.COORDINATOR])
            .exclude(status=Status.ARCHIVED)
            .order_by("last_name", "first_name", "pk")
        )
        if extension.coordinator_id:
            people = people.exclude(pk=extension.coordinator_id)
        self.fields["user"].queryset = people



class AddPeopleForm(forms.Form):
    """Pick the people to transfer INTO one extension (from any extension).

    The page's datalist builds a list of chosen people; each id arrives as a
    hidden `people` field. Only members and coordinators who are not archived
    and not already in the extension qualify.
    """

    people = forms.ModelMultipleChoiceField(queryset=User.objects.none(), widget=forms.MultipleHiddenInput())

    def __init__(self, *args, extension, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["people"].queryset = (
            User.objects.filter(role__in=[Role.MEMBER, Role.COORDINATOR])
            .exclude(status=Status.ARCHIVED)
            .exclude(extension=extension)
            .select_related("extension")
        )


# ================================================================== people
class UserForm(forms.Form):
    """Details, role and extension fields shared by person create and edit forms.

    actor           -- decides which roles appear in the role list.
    keep_role       -- the person's current role when it cannot be handed out (a
                       super-admin): it is shown, read-only, and kept.
    exclude_pk      -- the person being edited, left out of the duplicate-name check.
    keep_extension  -- id of the extension the person is already in, so it stays
                       selectable even if that extension has since been archived.
    The role decides the extension: coordinator and member need one; admin and
    super-admin never have one (the choice is dropped).
    """

    first_name = forms.CharField(max_length=150, strip=True, widget=forms.TextInput(attrs={"class": "input"}))
    middle_name = forms.CharField(
        max_length=150, strip=True, required=False, widget=forms.TextInput(attrs={"class": "input"}),
    )
    last_name = forms.CharField(max_length=150, strip=True, widget=forms.TextInput(attrs={"class": "input"}))
    suffix = forms.CharField(
        max_length=10, strip=True, required=False, label="Suffix",
        widget=forms.TextInput(attrs={"class": "input", "placeholder": "Jr., Sr., III", "autocomplete": "off"}),
    )
    birth_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={"class": "input", "type": "date"}, format="%Y-%m-%d"),
    )
    # Required. People saved before the rule may still have none; they are forced to pick one the
    # next time a leader edits them. (The member's own profile page does not show it in v1.)
    gender = forms.ChoiceField(
        required=True, label="Gender", choices=[("", "Choose a gender"), *Gender.choices],
        widget=forms.Select(attrs={"class": "input"}),
        error_messages={"required": "Choose a gender."},
    )
    role = forms.ChoiceField(widget=forms.Select(attrs={"class": "input", "x-model": "role"}))
    # The page renders a dropdown; the server still checks the selected extension.
    extension = ExtensionChoiceField(
        queryset=Extension.objects.none(), required=False, empty_label="Choose an extension",
        widget=forms.Select(attrs={"class": "input", "x-model": "extId", "@change": "pick()"}),
    )
    # Set by the confirmation dialog when a coordinator may replace the current one.
    replace_coordinator = forms.BooleanField(required=False, widget=forms.HiddenInput())

    # Optional contact details (so a coordinator can follow someone up). The address has the
    # same parts as an extension; the page turns the Philippine ones into cascading dropdowns.
    phone_number = forms.CharField(
        max_length=25, strip=True, required=False, label="Phone number",
        widget=forms.TextInput(attrs={
            "class": "input font-mono", "inputmode": "tel", "autocomplete": "off",
            "placeholder": "0917 123 4567",
        }),
    )
    country = forms.ChoiceField(
        required=False, label="Country", choices=[],
        widget=forms.Select(attrs={"class": "input", "x-model": "country", "autocomplete": "off"}),
    )
    province = forms.CharField(
        max_length=150, required=False, label="Province",
        widget=forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
    )
    municipality = forms.CharField(
        max_length=150, required=False, label="Municipality",
        widget=forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
    )
    barangay = forms.CharField(
        max_length=150, required=False, label="Barangay",
        widget=forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
    )
    postal_code = forms.CharField(
        max_length=10, required=False, label="Postal code",
        widget=forms.TextInput(attrs={
            "class": "input font-mono", "maxlength": "10", "inputmode": "numeric", "autocomplete": "off",
        }),
    )
    street = forms.CharField(
        max_length=150, required=False, label="Street",
        widget=forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
    )
    building_number = forms.CharField(
        max_length=50, required=False, label="Building number",
        widget=forms.TextInput(attrs={"class": "input", "autocomplete": "off"}),
    )

    def __init__(self, *args, actor, keep_extension=None, keep_role=None, exclude_pk=None,
                 saved_address=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.exclude_pk = exclude_pk
        # The person's saved address, so an old value that is no longer in the list can stay.
        self.saved_address = saved_address
        self.fields["country"].choices = [("", "Not given")] + [(c, c) for c in COUNTRIES]
        # A coordinator only ever works inside their own extension: it is fixed here and
        # again in the service, whatever the browser posts.
        self.fixed_extension = None
        if actor.role == Role.COORDINATOR:
            self.fixed_extension = Extension.objects.filter(pk=actor.extension_id).first()
        # A coordinator cannot choose a password or skip activation: new people get the global
        # member password and must change it. The service refuses it too.
        if not can_type_password(actor):
            self.fields.pop("password", None)
            self.fields.pop("activated", None)
        roles = list(assignable_roles(actor))
        if keep_role and keep_role not in roles:
            roles.insert(0, keep_role)
            self.fields["role"].disabled = True     # the value comes from `initial`
        self.fields["role"].choices = [(r, Role(r).label) for r in roles]
        allowed = Q(archived_at__isnull=True)
        if keep_extension:
            allowed |= Q(pk=keep_extension)
        extensions = Extension.objects.filter(allowed)
        if self.fixed_extension is not None:
            extensions = extensions.filter(pk=self.fixed_extension.pk)
        self.fields["extension"].queryset = extensions.select_related("coordinator").order_by("name")

    @cached_property
    def extension_data(self):
        """Choosable extensions for the page's datalist and its coordinator warning.

        One dict per extension: id, name (title case), the current coordinator's
        name ("" when none) and id (None when none).
        """
        return [
            {
                "id": ext.pk,
                "name": title_case(ext.name),
                "coordinator": ext.coordinator.full_name if ext.coordinator else "",
                "coordinatorId": ext.coordinator_id,
            }
            for ext in self.fields["extension"].queryset
        ]

    # Names are stored lowercase with single spaces; the pages show them in name case.
    def clean_first_name(self):
        return clean_text(self.cleaned_data.get("first_name"))

    def clean_middle_name(self):
        return clean_text(self.cleaned_data.get("middle_name"))

    def clean_last_name(self):
        return clean_text(self.cleaned_data.get("last_name"))

    def clean_suffix(self):
        return normalize_suffix(self.cleaned_data.get("suffix"))

    def clean_phone_number(self):
        value = clean_phone(self.cleaned_data.get("phone_number"))
        if value and not is_valid_phone(value):
            raise ValidationError(PHONE_MESSAGE)
        return value

    # Address text is stored the way an extension stores it: lowercase, single spaces.
    def clean_country(self):
        return clean_text(self.cleaned_data.get("country"))

    def clean_province(self):
        return clean_text(self.cleaned_data.get("province"))

    def clean_municipality(self):
        return clean_text(self.cleaned_data.get("municipality"))

    def clean_barangay(self):
        return clean_text(self.cleaned_data.get("barangay"))

    def clean_street(self):
        return clean_text(self.cleaned_data.get("street"))

    def clean_building_number(self):
        return clean_text(self.cleaned_data.get("building_number"))

    def clean_postal_code(self):
        """Single spaces only; the case is left alone (foreign codes like 'SW1A 1AA')."""
        return " ".join((self.cleaned_data.get("postal_code") or "").split())

    @property
    def address_state(self):
        """Current country/province/municipality/barangay for the page's JavaScript."""
        return {name: self[name].value() or "" for name in HIERARCHY}

    def clean(self):
        cleaned = super().clean()
        role = cleaned.get("role")
        if role in (Role.COORDINATOR, Role.MEMBER):
            if self.fixed_extension is not None:
                cleaned["extension"] = self.fixed_extension
            elif cleaned.get("extension") is None and "extension" not in self.errors:
                self.add_error("extension", "Choose an extension for this role.")
        elif role:
            cleaned["extension"] = None

        # The address is optional, but whatever is filled in must make sense.
        address = {name: cleaned.get(name) or "" for name in ADDRESS_FIELDS}
        if any(address.values()):
            if not address["country"]:
                if "country" not in self.errors:
                    self.add_error("country", "Choose a country for the address, or clear it.")
            else:
                for field, message in check_address(address, self.saved_address).items():
                    if field not in self.errors:
                        self.add_error(field, message)

        names_ok = cleaned.get("first_name") and cleaned.get("last_name") and not any(
            n in self.errors for n in ("first_name", "middle_name", "last_name", "birth_date")
        )
        if names_ok:
            # Imported here: the services import the models, never the forms.
            from .services.users import duplicate_message
            message = duplicate_message(cleaned, exclude_pk=self.exclude_pk)
            if message:
                self.add_error(None, message)
        return cleaned


class UserCreateForm(UserForm):
    """New person. A blank password means: use the default, or generate one."""

    password = forms.CharField(
        required=False, strip=False, label="Password",
        widget=forms.PasswordInput(attrs={"class": "input", "autocomplete": "new-password"}, render_value=False),
        help_text="Leave empty to use your default password for this role, or a generated one shown once.",
    )
    activated = forms.BooleanField(
        required=False, label="Skip activation",
        widget=forms.CheckboxInput(attrs={"class": "mt-0.5 size-4 accent-accent"}),
        help_text="The account is active at once and is not asked to change the password. Meant for test accounts.",
    )

    def clean_password(self):
        value = self.cleaned_data.get("password") or ""
        if value and len(value) < 8:
            raise ValidationError("Use at least 8 characters, or leave it empty.")
        return value


class UserFilterForm(forms.Form):
    """Search, filters and sort for the people list (GET parameters)."""

    STATUS_CHOICES = [
        ("current", "Not archived"),
        ("not_activated", "Not activated"),
        ("active", "Active"),
        ("suspended", "Suspended"),
        ("archived", "Archived"),
        ("all", "All"),
    ]
    ROLE_CHOICES = [("", "All roles"), *Role.choices]
    SORT_CHOICES = [
        ("last_name", "Last name, A to Z"),
        ("-last_name", "Last name, Z to A"),
        ("first_name", "First name, A to Z"),
        ("-first_name", "First name, Z to A"),
        ("account_id", "Account ID, lowest first"),
        ("-account_id", "Account ID, highest first"),
    ]

    q = forms.CharField(
        required=False, strip=True, max_length=100, label="Search",
        widget=forms.TextInput(attrs={"class": "input", "placeholder": "Name or account ID"}),
    )
    status = forms.ChoiceField(
        required=False, choices=STATUS_CHOICES, label="Status",
        widget=forms.Select(attrs={"class": "input"}),
    )
    role = forms.ChoiceField(
        required=False, choices=ROLE_CHOICES, label="Role",
        widget=forms.Select(attrs={"class": "input"}),
    )
    extension = forms.ModelChoiceField(
        queryset=Extension.objects.order_by("name"), required=False, empty_label="All extensions",
        widget=forms.Select(attrs={"class": "input"}),
    )
    special_role = forms.ChoiceField(
        required=False, label="Special role",
        choices=[("", "Anyone"), ("tithes_offering", "Tithes member"), ("attendance", "Attendance member")],
        widget=forms.Select(attrs={"class": "input"}),
    )
    sort = forms.ChoiceField(
        required=False, choices=SORT_CHOICES, label="Sort by",
        widget=forms.Select(attrs={"class": "input"}),
    )


class DefaultPasswordsForm(forms.Form):
    """The signed-in person's own default passwords: one optional password and one Remove tick per role.

    roles -- the roles this person keeps a default for (permissions.default_password_roles).
    An empty password field leaves that default as it is. `changes` is what to save.
    """

    MIN_LENGTH = 8

    def __init__(self, *args, roles, **kwargs):
        super().__init__(*args, **kwargs)
        self.roles = list(roles)
        for role in self.roles:
            label = Role(role).label
            self.fields[f"password_{role}"] = forms.CharField(
                required=False, strip=False, label=f"{label} default password",
                widget=forms.PasswordInput(
                    attrs={
                        "class": "input font-mono",
                        "autocomplete": "new-password",
                        "x-bind:type": "show ? 'text' : 'password'",
                    },
                    render_value=False,
                ),
            )
            self.fields[f"clear_{role}"] = forms.BooleanField(
                required=False, label="Remove",
                widget=forms.CheckboxInput(attrs={"class": "size-4 accent-accent"}),
            )

    def clean(self):
        cleaned = super().clean()
        for role in self.roles:
            password = cleaned.get(f"password_{role}") or ""
            if password and cleaned.get(f"clear_{role}"):
                self.add_error(f"password_{role}", "Type a password or tick Remove, not both.")
            elif password:
                try:
                    validate_strong_password(password)
                except ValidationError as e:
                    self.add_error(f"password_{role}", e)
        return cleaned

    @property
    def changes(self):
        """{role: ("set", password) | ("clear", None)} for what the person filled in."""
        out = {}
        for role in self.roles:
            password = self.cleaned_data.get(f"password_{role}") or ""
            if password:
                out[role] = ("set", password)
            elif self.cleaned_data.get(f"clear_{role}"):
                out[role] = ("clear", None)
        return out

# ============================================================ activation
def clean_new_password(self):
    value = self.cleaned_data["new_password"]
    if self.user.check_password(value):
        raise ValidationError("Choose a password different from your temporary one.")
    validate_strong_password(value)
    validate_password(value, self.user)
    return value

def clean_password(self):
    value = self.cleaned_data.get("password") or ""
    if value:
        validate_strong_password(value)
    return value

class ActivationForm(forms.Form):
    """Choose a new password (twice) to finish activation.

    user -- the signed-in person. Used to refuse reusing the temporary
    password and for Django's password validators (length, common
    passwords, all-numeric, similarity to the person's own details).
    """

    new_password = forms.CharField(strip=False, widget=forms.PasswordInput, label="New password")
    confirm_password = forms.CharField(strip=False, widget=forms.PasswordInput, label="Confirm password")

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user

    def clean_new_password(self):
        value = self.cleaned_data["new_password"]
        if self.user.check_password(value):
            raise ValidationError("Choose a password different from your temporary one.")
        validate_password(value, self.user)  # raises ValidationError with every problem
        return value

    def clean(self):
        cleaned = super().clean()
        new, confirm = cleaned.get("new_password"), cleaned.get("confirm_password")
        if new and confirm and new != confirm:
            self.add_error("confirm_password", "The two passwords do not match.")
        return cleaned

# ============================================================ profile
PHOTO_MAX_BYTES = 2 * 1024 * 1024
PHOTO_FORMATS = {"JPEG", "PNG", "WEBP"}
BIRTH_DATE_EARLIEST = date(1900, 1, 1)


class ProfileDetailsForm(forms.Form):
    """The only details a person edits themselves: birth date and photo.

    user -- the signed-in person. Needed because a birth date that is already
    set cannot be removed. The photo is optional: leaving it empty keeps the
    current one. Shape checks only (size, format); the service re-encodes it.
    """

    birth_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={"class": "input", "type": "date"}, format="%Y-%m-%d"),
    )
    photo = forms.ImageField(required=False)

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user
        self.fields["birth_date"].initial = user.birth_date
        self.fields["birth_date"].widget.attrs["max"] = timezone.localdate().isoformat()

    def clean_birth_date(self):
        value = self.cleaned_data.get("birth_date")
        if value is None:
            if self.user.birth_date:
                raise ValidationError("Birth date cannot be removed once it is set.")
            return None
        if value > timezone.localdate():
            raise ValidationError("Birth date cannot be in the future.")
        if value < BIRTH_DATE_EARLIEST:
            raise ValidationError("Enter a valid birth date.")
        return value

    def clean_photo(self):
        photo = self.cleaned_data.get("photo")
        if not photo:
            return None
        if photo.size > PHOTO_MAX_BYTES:
            raise ValidationError("The photo must be 2 MB or smaller.")
        image_format = getattr(getattr(photo, "image", None), "format", None)
        if image_format not in PHOTO_FORMATS:
            raise ValidationError("Use a JPG, PNG or WebP photo.")
        return photo


class ProfileEmailForm(forms.Form):
    """One email address to verify (a new one, or a replacement for the current one)."""

    email = forms.EmailField(
        max_length=254,
        widget=forms.EmailInput(attrs={
            "class": "input px-4 py-3 text-base", "autocomplete": "email",
            "inputmode": "email", "autocapitalize": "none",
        }),
    )

    def clean_email(self):
        return self.cleaned_data["email"].strip().lower()


class ChangePasswordForm(forms.Form):
    """Current password, then the new one twice.

    Whether the current password is right is decided by the service (it also
    audits wrong attempts); this form checks the shape of the new password.
    """

    current_password = forms.CharField(strip=False, widget=forms.PasswordInput, label="Current password")
    new_password = forms.CharField(strip=False, widget=forms.PasswordInput, label="New password")
    confirm_password = forms.CharField(strip=False, widget=forms.PasswordInput, label="Confirm new password")

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user

    def clean_new_password(self):
        value = self.cleaned_data["new_password"]
        if self.user.check_password(value):
            raise ValidationError("Choose a password different from your current one.")
        validate_password(value, self.user)  # raises ValidationError listing every problem
        return value

    def clean(self):
        cleaned = super().clean()
        new, confirm = cleaned.get("new_password"), cleaned.get("confirm_password")
        if new and confirm and new != confirm:
            self.add_error("confirm_password", "The two passwords do not match.")
        return cleaned


# ============================================================ forgot / reset password
class ForgotPasswordForm(forms.Form):
    """One box: an account id or a verified email.

    No shape check on purpose: the page must answer the same way for anything
    typed, so a badly shaped value is simply treated as "no match" by the service.
    """

    identifier = forms.CharField(
        max_length=254, strip=True, label="Account ID or email",
        widget=forms.TextInput(attrs={
            "class": "input px-4 py-3.5 text-base font-mono",
            "autocomplete": "username", "autocapitalize": "none", "autofocus": True,
        }),
    )


class ResetPasswordForm(forms.Form):
    """Choose a new password (twice) from the emailed link.

    user -- the person the link belongs to (NOT request.user: nobody is signed in).
    Used to refuse the current password and for Django's similarity validator.
    """

    new_password = forms.CharField(strip=False, widget=forms.PasswordInput, label="New password")
    confirm_password = forms.CharField(strip=False, widget=forms.PasswordInput, label="Confirm new password")

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user

    def clean_new_password(self):
        value = self.cleaned_data["new_password"]
        if self.user.check_password(value):
            raise ValidationError("Choose a password different from your current one.")
        validate_strong_password(value)
        validate_password(value, self.user)  # raises ValidationError listing every problem
        return value

    def clean(self):
        cleaned = super().clean()
        new, confirm = cleaned.get("new_password"), cleaned.get("confirm_password")
        if new and confirm and new != confirm:
            self.add_error("confirm_password", "The two passwords do not match.")
        return cleaned
